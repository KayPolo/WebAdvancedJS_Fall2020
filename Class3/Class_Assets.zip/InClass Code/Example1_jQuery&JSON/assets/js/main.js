/*------------------------------------

	1. Comparing Vanilla JS with jQuery
	
---------------------------------------*/






/*--------------------------------------------------

	2. Understanding how to build an object 
	and call information inside the object.

--------------------------------------------------*/







/*--------------------------------------------------

	3. Creating a data set that contains an array of objects

--------------------------------------------------*/






/*--------------------------------------------------

	4. Stringify the JSON Data and converting it back to JSON format

--------------------------------------------------*/




/*--------------------------------------------------

	5. Understanding for loops and pulling data from a json file.

--------------------------------------------------*/