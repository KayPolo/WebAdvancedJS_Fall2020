//https://openweathermap.org/api
// We're going to work with the current weather
// You need to register in order to obtain a key

//-------------------------------------------------------------
//Your Code Starts here














//-------------------------------------------------------------

// Other Resources

// JSON vs XML 
// https://restfulapi.net/json-vs-xml/

// AJAX Call vs getJSON Call
//https://medium.com/@KDweber89/ajax-vs-getjson-ca910fa6854e