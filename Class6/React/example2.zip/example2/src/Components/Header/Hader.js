import React from 'react';
import './Header.css'

const Header  = ()=>{
 
        return(
            <div className = 'header'>
                <span>Title</span>
                <ul>
                    <li>Link 1</li>
                    <li>Link 2</li>
                    <li>Link 3</li>
                </ul>
            </div>
        );

}

export default Header;