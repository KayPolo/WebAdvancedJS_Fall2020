import React, {Component} from 'react';
import './App.css';
import Header from './components/Header/Header';

class App extends Component {

//   render(){
//   return (
//     // even thougt this looks like html, it isn't. This is JSX
//     //This is JavaScript and it get's compiled into the lines below
    
//     //Tipically you nest everything in one single componnent
//     //This wrap is used so you can write in html-like
//     <div className="App">
//       <h1>This is my React App</h1>
//       <p>This is pretty cool</p>
//       {/* <Header/> */}

//       <h1>Today's winers are : <br/>
//       {/* <Header/>
//       <Header/>
//       <Header/> */}

//       <Header name = 'Karla' age = '30'></Header>
//       <Header name = 'Brandon' age = '26'> I'm so young</Header>
//       <Header name = 'Renato' age = '34'></Header>
    
//       </h1>

//     </div>
//   );
// }

  state = {
    persons:[
      {name:'Karla' , age:30},
      {name:'Brandon' , age:26},
      {name:'Tuba' , age:29}

    ]
  }

  switchName = ()=>{
    console.log('Button clicked');

    this.setState({
      persons:[
        {name:'Anna' , age:50},
        {name:'Ben' , age:26},
        {name:'Tuba' , age:33}
  
      ]}
    );
  }


  render(){
    return(

     <div className="App">
      <h1>This is my React App</h1>
      <p>This is pretty cool</p>

      <button onClick = {this.switchName}>Switch Name</button>
      {/* <button onClick = {()=>{this.switchName()}}>Switch Name</button> */}

      <Header name = {this.state.persons[0].name} age = {this.state.persons[0].age}></Header>
      <Header name = {this.state.persons[1].name} age = {this.state.persons[1].age}></Header>
      <Header name = {this.state.persons[2].name} age = {this.state.persons[2].age}></Header>


    </div>

    );
  }



  //this is equal to:
  //return React.createElement('div',null, React.createElement('h1', null,"Hi, I'm a react app"))
  //return React.createElement('div',{className:'App'}, React.createElement('h1', null,"Hi, I'm a react app"))
}

export default App;
