//import React, {Component} from 'react';
import React from 'react';
import './Header.css';


// class Header extends Component{
//   render(){
//     return <h1>This is another component</h1>

//   }
// }

// function Header() {

  
//     return <h1>This is another component</h1>

  
   
//   }


// const anotherComponent  = ()=>{
//   return (
//   <div>
//       <h2 className='text'>This is another component</h2>
//       <p>This is amazing!!!!</p>
//   </div>
  
//   );

         
// }


//We can also add dynamic content

// const anotherComponent  = ()=>{
//   return (
//   <div>
//       <h2 className='text'>Number: {Math.floor(Math.random() * 30)}</h2>
 
//   </div>
  
//   );

         
// }


//the reason why we should use functions as much as we can insted of extend component classes
//is better to controll this way (Not having diffent states, etc.)

const people  = (props)=>{
  
  return (
  <div>
      
      <h2 className='text'>I'm {props.name}, I am {props.age} years old</h2>

      {/* the reason why I need to do this is so it understands that there is a children between the tags */}
      <div>{props.children}</div>
 
  </div>
  
  );

         
}

  
//export default Header;

//export default anotherComponent;

export default people;