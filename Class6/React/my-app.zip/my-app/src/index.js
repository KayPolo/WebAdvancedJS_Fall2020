import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

import * as serviceWorker from './serviceWorker';

//import Header from './components/Header/Header'

ReactDOM.render(<App />, document.getElementById('root'));

//ReactDOM.render(<Header />, document.getElementById('root'));

//Technically you could render each component individually like this:
//ReactDOM.render(<h1>This is my React App</h1>, document.getElementById('root'));
//but this is not efficient, that's why we create a root componnent that has all the html components
//that your application will need

serviceWorker.register();


